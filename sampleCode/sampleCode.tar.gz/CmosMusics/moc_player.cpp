/****************************************************************************
** Meta object code from reading C++ file 'player.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "src/player.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'player.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Player_t {
    QByteArrayData data[48];
    char stringdata[514];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_Player_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_Player_t qt_meta_stringdata_Player = {
    {
QT_MOC_LITERAL(0, 0, 6),
QT_MOC_LITERAL(1, 7, 10),
QT_MOC_LITERAL(2, 18, 0),
QT_MOC_LITERAL(3, 19, 13),
QT_MOC_LITERAL(4, 33, 12),
QT_MOC_LITERAL(5, 46, 13),
QT_MOC_LITERAL(6, 60, 11),
QT_MOC_LITERAL(7, 72, 16),
QT_MOC_LITERAL(8, 89, 15),
QT_MOC_LITERAL(9, 105, 3),
QT_MOC_LITERAL(10, 109, 15),
QT_MOC_LITERAL(11, 125, 8),
QT_MOC_LITERAL(12, 134, 13),
QT_MOC_LITERAL(13, 148, 3),
QT_MOC_LITERAL(14, 152, 12),
QT_MOC_LITERAL(15, 165, 19),
QT_MOC_LITERAL(16, 185, 3),
QT_MOC_LITERAL(17, 189, 7),
QT_MOC_LITERAL(18, 197, 10),
QT_MOC_LITERAL(19, 208, 4),
QT_MOC_LITERAL(20, 213, 3),
QT_MOC_LITERAL(21, 217, 13),
QT_MOC_LITERAL(22, 231, 6),
QT_MOC_LITERAL(23, 238, 5),
QT_MOC_LITERAL(24, 244, 4),
QT_MOC_LITERAL(25, 249, 24),
QT_MOC_LITERAL(26, 274, 25),
QT_MOC_LITERAL(27, 300, 11),
QT_MOC_LITERAL(28, 312, 18),
QT_MOC_LITERAL(29, 331, 19),
QT_MOC_LITERAL(30, 351, 5),
QT_MOC_LITERAL(31, 357, 21),
QT_MOC_LITERAL(32, 379, 19),
QT_MOC_LITERAL(33, 399, 21),
QT_MOC_LITERAL(34, 421, 2),
QT_MOC_LITERAL(35, 424, 8),
QT_MOC_LITERAL(36, 433, 4),
QT_MOC_LITERAL(37, 438, 4),
QT_MOC_LITERAL(38, 443, 5),
QT_MOC_LITERAL(39, 449, 4),
QT_MOC_LITERAL(40, 454, 8),
QT_MOC_LITERAL(41, 463, 4),
QT_MOC_LITERAL(42, 468, 9),
QT_MOC_LITERAL(43, 478, 4),
QT_MOC_LITERAL(44, 483, 9),
QT_MOC_LITERAL(45, 493, 8),
QT_MOC_LITERAL(46, 502, 6),
QT_MOC_LITERAL(47, 509, 3)
    },
    "Player\0urlChanged\0\0QMediaContent\0"
    "titleChanged\0artistChanged\0nameChanged\0"
    "isPlayingChanged\0positionChanged\0pos\0"
    "durationChanged\0duration\0volumeChanged\0"
    "vol\0errorOccured\0QMediaPlayer::Error\0"
    "err\0message\0eofReached\0load\0url\0"
    "albumImagPath\0artist\0title\0name\0"
    "handleMediaStatusChanged\0"
    "QMediaPlayer::MediaStatus\0mediaStatus\0"
    "handleStateChanged\0QMediaPlayer::State\0"
    "state\0handlePositionChanged\0"
    "handleVolumeChanged\0handleCurMediaChanged\0"
    "mc\0loadPath\0path\0play\0pause\0stop\0"
    "previous\0next\0playIndex\0nPos\0isPlaying\0"
    "position\0volume\0uri\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Player[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      27,   14, // methods
       8,  210, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      10,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  149,    2, 0x05,
       4,    1,  152,    2, 0x05,
       5,    1,  155,    2, 0x05,
       6,    1,  158,    2, 0x05,
       7,    0,  161,    2, 0x05,
       8,    1,  162,    2, 0x05,
      10,    1,  165,    2, 0x05,
      12,    1,  168,    2, 0x05,
      14,    2,  171,    2, 0x05,
      18,    0,  176,    2, 0x05,

 // slots: name, argc, parameters, tag, flags
      19,    1,  177,    2, 0x0a,
      21,    0,  180,    2, 0x0a,
      22,    0,  181,    2, 0x0a,
      23,    0,  182,    2, 0x0a,
      24,    0,  183,    2, 0x0a,
      25,    1,  184,    2, 0x08,
      28,    1,  187,    2, 0x08,
      31,    1,  190,    2, 0x08,
      32,    1,  193,    2, 0x08,
      33,    1,  196,    2, 0x08,

 // methods: name, argc, parameters, tag, flags
      35,    1,  199,    2, 0x02,
      37,    0,  202,    2, 0x02,
      38,    0,  203,    2, 0x02,
      39,    0,  204,    2, 0x02,
      40,    0,  205,    2, 0x02,
      41,    0,  206,    2, 0x02,
      42,    1,  207,    2, 0x02,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::LongLong,    9,
    QMetaType::Void, QMetaType::LongLong,   11,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, 0x80000000 | 15, QMetaType::QString,   16,   17,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,   20,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::Void, 0x80000000 | 26,   27,
    QMetaType::Void, 0x80000000 | 29,   30,
    QMetaType::Void, QMetaType::LongLong,    9,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, 0x80000000 | 3,   34,

 // methods: parameters
    QMetaType::Void, QMetaType::QString,   36,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   43,

 // properties: name, type, flags
      44, QMetaType::Bool, 0x00495001,
      45, QMetaType::Int, 0x00495003,
      11, QMetaType::Int, 0x00495001,
      46, QMetaType::Int, 0x00495103,
      47, QMetaType::QString, 0x00495001,
      22, QMetaType::QString, 0x00495001,
      23, QMetaType::QString, 0x00495001,
      24, QMetaType::QString, 0x00495001,

 // properties: notify_signal_id
       4,
       5,
       6,
       7,
       0,
       2,
       1,
       3,

       0        // eod
};

void Player::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Player *_t = static_cast<Player *>(_o);
        switch (_id) {
        case 0: _t->urlChanged((*reinterpret_cast< QMediaContent(*)>(_a[1]))); break;
        case 1: _t->titleChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->artistChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->nameChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->isPlayingChanged(); break;
        case 5: _t->positionChanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 6: _t->durationChanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 7: _t->volumeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->errorOccured((*reinterpret_cast< QMediaPlayer::Error(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 9: _t->eofReached(); break;
        case 10: _t->load((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: { QString _r = _t->albumImagPath();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 12: { QString _r = _t->artist();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 13: { QString _r = _t->title();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 14: { QString _r = _t->name();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 15: _t->handleMediaStatusChanged((*reinterpret_cast< QMediaPlayer::MediaStatus(*)>(_a[1]))); break;
        case 16: _t->handleStateChanged((*reinterpret_cast< QMediaPlayer::State(*)>(_a[1]))); break;
        case 17: _t->handlePositionChanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 18: _t->handleVolumeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->handleCurMediaChanged((*reinterpret_cast< QMediaContent(*)>(_a[1]))); break;
        case 20: _t->loadPath((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 21: _t->play(); break;
        case 22: _t->pause(); break;
        case 23: _t->stop(); break;
        case 24: _t->previous(); break;
        case 25: _t->next(); break;
        case 26: _t->playIndex((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QMediaContent >(); break;
            }
            break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QMediaPlayer::Error >(); break;
            }
            break;
        case 15:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QMediaPlayer::MediaStatus >(); break;
            }
            break;
        case 16:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QMediaPlayer::State >(); break;
            }
            break;
        case 19:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QMediaContent >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Player::*_t)(QMediaContent );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Player::urlChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (Player::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Player::titleChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (Player::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Player::artistChanged)) {
                *result = 2;
            }
        }
        {
            typedef void (Player::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Player::nameChanged)) {
                *result = 3;
            }
        }
        {
            typedef void (Player::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Player::isPlayingChanged)) {
                *result = 4;
            }
        }
        {
            typedef void (Player::*_t)(qint64 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Player::positionChanged)) {
                *result = 5;
            }
        }
        {
            typedef void (Player::*_t)(qint64 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Player::durationChanged)) {
                *result = 6;
            }
        }
        {
            typedef void (Player::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Player::volumeChanged)) {
                *result = 7;
            }
        }
        {
            typedef void (Player::*_t)(QMediaPlayer::Error , QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Player::errorOccured)) {
                *result = 8;
            }
        }
        {
            typedef void (Player::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Player::eofReached)) {
                *result = 9;
            }
        }
    }
}

const QMetaObject Player::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Player.data,
      qt_meta_data_Player,  qt_static_metacall, 0, 0}
};


const QMetaObject *Player::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Player::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Player.stringdata))
        return static_cast<void*>(const_cast< Player*>(this));
    return QObject::qt_metacast(_clname);
}

int Player::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = isPlaying(); break;
        case 1: *reinterpret_cast< int*>(_v) = position(); break;
        case 2: *reinterpret_cast< int*>(_v) = duration(); break;
        case 3: *reinterpret_cast< int*>(_v) = volume(); break;
        case 4: *reinterpret_cast< QString*>(_v) = currentUrl(); break;
        case 5: *reinterpret_cast< QString*>(_v) = artist(); break;
        case 6: *reinterpret_cast< QString*>(_v) = title(); break;
        case 7: *reinterpret_cast< QString*>(_v) = name(); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 1: seek(*reinterpret_cast< int*>(_v)); break;
        case 3: setVolume(*reinterpret_cast< int*>(_v)); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void Player::urlChanged(QMediaContent _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Player::titleChanged(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Player::artistChanged(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Player::nameChanged(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Player::isPlayingChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void Player::positionChanged(qint64 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void Player::durationChanged(qint64 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void Player::volumeChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void Player::errorOccured(QMediaPlayer::Error _t1, QString _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void Player::eofReached()
{
    QMetaObject::activate(this, &staticMetaObject, 9, 0);
}
QT_END_MOC_NAMESPACE
